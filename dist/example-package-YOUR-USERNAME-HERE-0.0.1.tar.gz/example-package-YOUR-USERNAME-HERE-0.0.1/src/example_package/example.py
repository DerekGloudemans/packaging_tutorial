def fun1(x):
     return x**2

