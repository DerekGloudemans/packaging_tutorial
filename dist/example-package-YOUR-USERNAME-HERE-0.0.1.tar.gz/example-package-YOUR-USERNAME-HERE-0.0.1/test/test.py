from src.example_package import example4
from src.example_package.module.sub_example2 import fun3
fun3(4)
