from ..example import fun1


def fun3(x):
     return fun1(x) + 4

