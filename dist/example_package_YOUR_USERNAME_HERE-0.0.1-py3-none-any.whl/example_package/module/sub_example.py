
from .sub_example2 import fun3
from ..example import fun1

def fun2(x):
     return fun1(x) + fun3(x)

