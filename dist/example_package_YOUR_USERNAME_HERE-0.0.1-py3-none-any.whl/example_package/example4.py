from .module.sub_example import fun2

fun2(3)
